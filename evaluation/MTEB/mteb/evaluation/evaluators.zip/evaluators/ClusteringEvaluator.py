import logging

import numpy as np
import sklearn
import sklearn.cluster


logger = logging.getLogger(__name__)

from .Evaluator import Evaluator

DEFINITIONS = {
    'short': {
        'TwentyNewsgroupsClustering': 'Relate:',
        'BiorxivClusteringS2S': 'Relate:',
        'MedrxivClusteringS2S original': 'Cluster:',
        'MedrxivClusteringS2S': 'Represent a medical sentence:',
    },
    'long': {
        'TwentyNewsgroupsClustering': 'same: Retrieve a duplicate sentence ',
        'BiorxivClusteringS2S': 'Relate:',
        'MedrxivClusteringS2S': 'Cluster:',
    },
    'v3': {
        'TwentyNewsgroupsClustering': 'Encode the title for clustering\n',
        'BiorxivClusteringS2S': 'Encode the title for clustering\n',
        'MedrxivClusteringS2S': 'Encode the title for clustering\n',
    }

}

class ClusteringEvaluator(Evaluator):
    def __init__(self, sentences, labels, clustering_batch_size=500, limit=None, **kwargs):
        super().__init__(**kwargs)
        if limit is not None:
            sentences = sentences[:limit]
            labels = labels[:limit]
        self.sentences = sentences
        self.labels = labels
        self.clustering_batch_size = clustering_batch_size
        self.args = kwargs['args']

    def __call__(self, model):
        logger.info(f"Encoding {len(self.sentences)} sentences...")
        new_sentences = []
        if self.args.prompt:
            print('with prompt')
            for s in self.sentences:
                new_sentences.append([DEFINITIONS[self.args.prompt][self.args.task_name], s, 0])
        else:
            new_sentences = self.sentences
        corpus_embeddings = np.asarray(model.encode(new_sentences))
        # mean_emb = np.mean(corpus_embeddings,axis=0)
        # corpus_embeddings -= mean_emb

        logger.info("Fitting Mini-Batch K-Means model...")
        clustering_model = sklearn.cluster.MiniBatchKMeans(
            n_clusters=len(set(self.labels)), batch_size=self.clustering_batch_size
        )
        clustering_model.fit(corpus_embeddings)
        cluster_assignment = clustering_model.labels_

        logger.info("Evaluating...")
        v_measure = sklearn.metrics.cluster.v_measure_score(self.labels, cluster_assignment)

        return {"v_measure": v_measure}
